const runTest = require('./test');
runTest('test/unit');