const runTest = require('./test');
runTest('test/integration');